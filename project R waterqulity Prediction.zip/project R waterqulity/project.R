## Read the dataset and get high level understanding
setwd('C:/Users/sahil sable/Documents/R/project R waterqulity')
getwd()
Auto <- read.csv("IndiaAffectedWaterQualityAreas.csv")

library(ggplot2) # Data visualization
library(readr) # CSV file I/O, e.g. the read_csv function

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory

system("ls ../input")
water_qual<-read.csv("IndiaAffectedWaterQualityAreas.csv",header=T,stringsAsFactor=FALSE)
str(water_qual)

# Any results you write to the current directory are saved as output.
# Lets see the data in the dataset
head(water_qual)
tail(water_qual)

# changing the variables names to ease of use
cnames<-c("state","district","block","panchayat","village","habitation","quality","year")

colnames(water_qual)<-cnames

library(ggplot2)
#library(lubridate)
library(dplyr)

#convert date column to year
water_qual$year<-format(as.Date(water_qual$year, format="%d/%m/%Y"),"%Y")

#plotiing the quality of water in india
ggplot(water_qual,aes(x=quality))+geom_bar(fill="chartreuse")

ggplot(water_qual,aes(x=year,y=quality,fill=factor(state)))+geom_bar(stat="identity")+theme(legend.position="bottom")

# filter data only to state "Tamil Nadu"
tn_wq_data<-water_qual %>% filter(state =="TAMIL NADU")
par(mfrow=c(1,2))
ggplot(tn_wq_data,aes(x=quality,fill=year))+geom_bar(position="dodge")+
  theme(axis.text.x = element_text(angle = 90))+scale_fill_brewer(palette="Spectral")

ggplot(tn_wq_data,aes(x=quality,fill=year))+geom_bar(position="fill")+
  ggtitle("Yearwise Water Quality in Tamilnadu")+scale_colour_brewer(palette="PRGn")

sta_qual<-data.frame(table(water_qual$state,water_qual$quality,water_qual$year))


sta_qual<-sta_qual %>% arrange(desc(Freq))


p <- ggplot(data = sta_qual, aes(x = Var1, y = Freq, group = Var2, fill = Var2))
p <- p + geom_bar(stat = "identity", width = 0.5, position = "dodge")
p <- p + theme_bw()
p <- p + theme(axis.text.x = element_text(angle = 90))
p<- p+ xlab("States")
p <-p+ylab("Count")
p <- p+ggtitle("State wise water Quality Proportion")+scale_fill_brewer(palette="Set1")
p

head(sta_qual)

sta_qual%>% ggplot(aes(x = Var3, y = Freq,fill=Var2))+geom_bar(stat="identity")+theme(axis.text.x=element_text(angle=90,hjust=0.5))+facet_wrap(~ Var1)+labs(title="Water Degradation in Indian States",x="Year",y="Freq")

# Most affected states are Rajasthan,Orissa,Assam and Bihar,west Bengal, Lets us analyse some of the states in detail
# In which area Salinity is high
affected<-data.frame(table(water_qual$state,water_qual$quality,water_qual$year,water_qual$district))


affected_fil<-affected %>%  filter(Var2=="Salinity" & Var1=="RAJASTHAN" & Freq>50)%>%arrange(desc(Freq))

head(affected_fil)

ggplot(affected_fil,aes(x=Var4,y=Freq,fill=Var3))+geom_bar(stat="identity",position="dodge")+coord_flip()+scale_fill_brewer(palette="PuRd")+labs(title="Districts in Rajasthan which are Salinity Affected")

rankq<-sta_qual %>% 
  group_by(Var2) %>% 
  mutate(rank = rank(-Freq, ties.method = "first"))
head(rankq)

rankq %>% group_by(Var2)%>% filter(rank <15)%>% ggplot( aes(x = Var1, y = rank,color=Var3)) + geom_point(size=3,alpha=0.7) +facet_wrap(~Var2)+theme(axis.text.x=element_text(angle=90,hjust=0.5))+scale_color_manual(values=c("red","purple","blue","green"))+labs(title="Top 15 water Degradation states",x="State",y="Rank")





# implementing map 

library(ggplot2)
library(maptools)

library(rgeos)

library(ggmap)

library(scales)
library(RColorBrewer)
set.seed(8000)

shp <- readShapeSpatial('~/Dropbox/PhD_Arka/Exploratory Indian Data Analysis/India Shapefile With Kashmir/india_shapefile_git/Admin2.shp')

#use rgdal::readOGR or sf::st_readuse rgdal::readOGR or sf::st_read

imr=read.csv('~/Dropbox/PhD_Arka/Exploratory Indian Data Analysis/health stat/IMR_R.csv')


ggplot()+geom_polygon(data = final.plot,aes(x = long, y = lat, group = group, fill = count),color = "black", size = 0.25) + coord_map()
ggsave(" https://www.google.com/url?sa=i&url=https%3A%2F%2Frpubs.com%2Fdrarka%2F435552&psig=AOvVaw12ivLUDJM29z4bdbtBT_IT&ust=1670898629502000&source=images&cd=vfe&ved=0CBAQjRxqFwoTCIjUrcuE8_sCFQAAAAAdAAAAABAE",dpi = 300, width = 20, height = 20, units = "cm")

